
library(readr)
library(ggmap)
library(reshape2)
library(ggthemes)
library(sf)
library(dplyr)

# You probably have to install these:
# install.packages("ggmap")
# install.packages("sf")

# It might be slightly problematic on some computers,
# if R studio is crushing, installing that several times solves the problem


# setting a working directory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))



# Intro -------------------------------------------------------------------

# In this tutorial we will examine the suicide cases in San Francisco
# For that purpose we will create various maps that will show us the layout of cases
# Firstly, be sure to understand the dataset!


suicide <- read_csv("san_francisco_suicide_2003_2017.csv")

suicide <- as.data.frame(suicide)

names(___)
head(____)
nrow(____)


suicide$Descript[1:15]




# Creating a map from coordinates -----------------------------------------

#we need to get the map first
#you can check coordinates at:
#https://boundingbox.klokantech.com/


# Note: Creating a map from coordinates with the use of online engine requires
# registering at engine's website and copy pasting API key
# I have done it for you, and save the result as a file that you have to load

# tutorial how to obtain API key: https://docs.stadiamaps.com/tutorials/getting-started-in-r-with-ggmap/


# Code for obtaining a map from coordinates:
# register_stadiamaps("API-KEY", write = TRUE)
# 
# sf_map <- ggmap(get_stadiamap(c(-122.530392,37.698887,-122.351177,37.812996),
#                               zoom= 12,
#                               #maptype = 'stamen_toner_lite', # different styles are possible
#                               source ="stadia"))
# saveRDS(sf_map, file = "sf_map.rds")



# Simply load the map from the external file
sf_map <- readRDS("sf_map.rds")

sf_map


# adding the layer with all the suicides to our map
# X and Y are names of the columns with coordinates from our dataset

sf_map + geom_point(data= suicide, aes(x= X, y= Y))




# Ex 1 --------------------------------------------------------------------

# Clean up Descript column, divide into attempted and accomplished and color by it;
# tweak size and alpha to make this look legible


# Firstly factorize the variable


str(suicide$Descript)


suicide_____ <- as.factor(___________)


# check the levels of factorized column
levels(____________)



# Notice that all categories in this variable starts with either attempted or successful
# we will create a new variable called 'status' that will be binary (attempted, successful) 


# In levels specify the categories that will cover all attempted cases,
# hint: in levels 9 first categories covers all "attempted" cases;
# hint2: ":" this argument creates a natural number sequence with difference 1

suicide$status <- ifelse(__________ %in% levels(_________)[_:_],
                         "attempted", "successful")




# status is a category, therefore it needs to be factorized 
# to make the visualization work, so do it and check the levels
suicide$status <- __________

levels(_________)



# The columns X and Y are our longitude and latitude columns,
# use our new status variable to color the points by attempted and successful 

sf_map+geom_point(aes(__________), data = ______, 
                  size = ___, alpha = ___)





# Ex 2 --------------------------------------------------------------------


# Fix these parameters to make this looks nice
#make sure one region stands out (it might ask you to install smth)
# use ONLY X and Y in aes()

sf_map+stat_binhex(_____________,
                   bins =60, data = _______)+
  coord_cartesian()



sf_map+stat_binhex(_____________,
                   bins = ______, _________, alpha = _____)+
  coord_cartesian()



#now add +scale_fill_gradient(low ="#ffeda0",high ="#f03b20")
#and revise sizes (bins) and alpha

sf_map+stat_binhex(____________,
                   _____________________________)+
  coord_cartesian()+____________________________




# Creating neighborhoods grid ---------------------------------------------

# We want to have specific districts of the city colored by variables
# For this reason we need to load the grid of the neighborhoods
# The grid was obtained from the internet, it is something that has to be found
# Many popular places has grids available e.g. grid of voivodeships in Poland


# load the data:

suicide$downtown <- (suicide$X < -122.446722 & suicide$Y > 37.773827)


sf_neighborhoods <-st_read("san_francisco_neighborhoods.shp")

sf_neighborhoods <-st_transform(sf_neighborhoods,crs =2227)

plot(sf_neighborhoods$geometry)


# creating status binary variable
suicide$statusID <- as.integer(suicide$status) - 1
str(suicide$statusID)

# creating downtown binary variable
suicide$downtownID <- as.integer(suicide$downtown) + 1
str(suicide$downtownID)




# Ex 3 --------------------------------------------------------------------

# NOW BY NEIGHBORHOODS, run the following lines
# try to understand what they do


suicideGeo <-st_as_sf(suicide,coords =c("X","Y"), crs ="+proj=longlat +ellps=WGS84 +no_defs")
suicideGeo <- st_transform(suicideGeo,crs= st_crs(sf_neighborhoods))

suicideGeo <- st_join(suicideGeo, sf_neighborhoods)

head(suicideGeo)


suicideGeo$number_suicides <- 1

names(suicideGeo)

suicideGeo$statusID

n_suicides <- aggregate(number_suicides ~ nhood, data = suicideGeo, FUN =sum)
n_successes <- aggregate(statusID ~ nhood, data = suicideGeo, FUN =sum)


neighborhoods <- merge(n_suicides,n_successes)


head(neighborhoods)

# after creating a summary table: neighborhood, attempted suicides count, successful suicides count
# let's rename the columns to make it more transparent
# change the names to attempts and suicides

colnames(neighborhoods)[c(2,3)] <- __________

sf_neighborhoods

# let's joint the data, to the table with coordinates,
# order matters as it is a left join!
# first the table with neighborhoods and coordinates (creating grid section)
# then neighborhoods and suicide attempts


sf_neighboorhood_summaries <- left_join(______, _______)


head(sf_neighboorhood_summaries)


# in case of NAs we are substituting them with 0s
________________________$attempts [is.na(
  _______________________$attempts )] <- 0



# create visualizations:
# one for suicides and one for attempted suicidies, check head() or names()
# of a data frame to pick the right columns
# add a theme
ggplot(______________________,aes(fill =___________))+geom_sf()+__________

ggplot((______________________,aes(fill =___________))+geom_sf()+__________


      
# now let's visualize suicide succes rate by neighberhood
# in fill argument put the ratio of attempted suicides to succesfull ones
# add: scale_fill_gradient('success rate', low ="skyblue",high ="darkorange")

# also, add a theme, and give it a title
       
ggplot(___________________,aes(fill = _______/_______))+
  ______


# try changing the theme to theme_void()

ggplot(___________________,aes(fill = _______/_______))+
  ______


# try to add: geom_sf_text(aes(label =paste( round(statusID/number_suicides * 100, 0), "%")), size = 2.5,
# color = "black", fontface = "bold", alpha = 0.8)



ggplot(___________________,aes(fill = _______/_______))+
  ______


# try to represent probabilities as percentages in geom_sf_text
# use paste(____, "%") to add a % symbol (after transforming the values :) )



ggplot(___________________,aes(fill = _______/_______))+
  ______


# You can save your map by running:
ggsave("neighborhoods.pdf")





