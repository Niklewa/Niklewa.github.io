library(dplyr)
library(tidyr)
library(ggthemes)
library(readr)
library(gganimate)
library(gifski)


# setting a working directory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


# Intro -------------------------------------------------------------------


# In this tutorial you will have to demonstrate what you have learned previously
# Complete all 3 sections to earn a grade, we will score the visualization's quality
# You don't have to complete it in one sitting 


#The Washington Post collects information about fatal police shootings
#https://www.washingtonpost.com/graphics/investigations/police-shootings-database/
#https://github.com/washingtonpost/data-police-shootings/tree/master/v2


# Load the dataset --------------------------------------------------------


shootings <- read_csv("fatal-police-shootings-data27042023.csv")



#1 Explore the data, 
#A. view the variables, understand what they mean, 
#B. make appropriate exploratory visualizations 



#2 Put forward an interesting hypothesis and visualize and summarize the relevant
#information


#3 Create a visualization that will show something meaningful







