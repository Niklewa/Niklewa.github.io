
# loading the packages
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

library(modelr)
library(kableExtra)
library(ggplot2)
library(ggthemes)
library(dplyr)
library(knitr)
library(nycflights13)
library(forcats)
library(tidyverse)
library(rethinking)
library(gridExtra)








