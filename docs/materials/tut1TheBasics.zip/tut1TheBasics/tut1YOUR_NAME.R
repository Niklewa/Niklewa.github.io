
# Tutorial 1, the basics


# 1 change the names of this file
# 2 Don't lose it!
# 3 Have fun with the exercises



# Exercise 1




# Exercise 2