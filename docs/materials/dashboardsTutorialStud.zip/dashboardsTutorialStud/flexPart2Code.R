library(ggplot2)
library(ggthemes)
library(gridExtra)
library(dplyr)
library(rethinking)


# here you should create tables that you will use for visualizations



# Infection causes vis ---------------------------------------------------------

# with this visualization we want to check what is the leading cause of HIV infections in each year
# use: droga_zakazenia to create a table that will have:
# rok, droga_zakazenia, count


HIVdata_9917 <- read.csv("HIV19992017PZH.csv")


head(HIVdata_9917)
unique(HIVdata_9917$droga_zakazenia)



# group by and summarize to have only 3 mentioned columns






# use only: kontakty_heteroseksualne, kontakty_homoseksualne, wstrzykiwanie_narkoty....
# so remove the rest of the variables (they are marginal causes)




# rename wstrzykiwanie_narkotyków_drogą_dożylną to IDU


# Factorize droga_zakazenia column!



# save your table as RDS to export it into the dashboard







# Testing among genders and sex orientations --------------------------------

# the idea is to visualize the amount of tests taken by different genders and,
# sexual orientations. The final result should be a table with: gender, orientacja, count

PKDdata <- read.csv("PKDjoint.csv")

# filter through Orinetacja, choose only: biseksualna, heteroseksualna, homoseksualna
# as the rest of the answers is marginal

# filter also Płeć, leave only M and K




# after that, group by Płeć and Orientacja, summarize



# save RDS file in order to export it to your dashboard


















