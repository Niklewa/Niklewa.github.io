
# install.packages("flexdashboard")
# install.packages("thematic")
# install.packages("bslib")

library(ggplot2)
library(ggthemes)
library(gridExtra)
library(dplyr)
library(rethinking)
library(sf)

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Map, hiv positive share ---------------------------------------------------

polandMap <- readRDS("poland_mapDF.RDS")
PKDdata <- read.csv("PKDjoint.csv")

# Notes on PKD variables
# IDU - injective drug user
# STP - quick HIV test
# TPR - regular test
# TPO - second test that is taken after the first one being positive


names(PKDdata) # it's big
head(PKDdata)
head(polandMap) # it's a special object, it has geometry column that we will use,
# to draw a map with Voivodeships 


# adding year column for further needs

PKDdata$Data_przeprowadzenia_rozmowy <- as.Date(PKDdata$Data_przeprowadzenia_rozmowy)

PKDdata$Year <- format(PKDdata$Data_przeprowadzenia_rozmowy, "%Y")


# the cases that have NA in TPO_wynik for sure are negative, so remove them

PKDdata$______[is.na(PKDdata$_____)] <- 0

unique(PKDdata$TPO_wynik)


# d means positive, instead of d we want 1, otherwise 0
# not sure where to put 0 and 1? 
# type ?ifelse()

positive_region <- ______  %>% 
  mutate(positive = ifelse(______ == "d", _, _ )) %>% 
  select(Płeć, Wiek, Year, positive, Województwo )


# let's group the outcomes by regions and results
# summarize by count
posit_region_group <- positive_region %>%
  group_by(Województwo, _______) %>%
  ____________________ %>%
  ungroup()

# there are NAs in the Województwo colum, let's remove them

posit_region_group <- posit_region_group[complete.cases(__________),]


# now let's add percentages column, with the ratio of positive to negative results,
# multiplied by 100

posit_region_group_perc <- posit_region_group %>% 
  group_by(Województwo) %>% 
  mutate(percent = _____ / sum(____) * 100)

# Nice! 
# For the purpose of visualization on the map, 
# let's include only positive cases (positive == 1)


posit1_region_group_perc <- posit_region_group_perc %>%
  __________________

posit1_region_group_perc

# let's merge our table with maps coordinates

map_percent_positive <- merge(polandMap, posit1_region_group_perc, by = "Województwo")


# Now we will save this table that we will use for the visualization
# remember to choose wisely working directory that you are currently in
# we are using different format, because there is geometry inside

st_write(map_percent_positive, "map_percent_positive.geojson")









# bubble plot-------------------------------------------------------------------

HIVdata_9917 <- read.csv("HIV19992017PZH.csv")
wojCitizens <- read.csv("wojCitizens.csv")

wojCitizens # data set with some information on polish Voivodeships

# we want to create a bubble plot with Voivodeships as bubbles
# on x and y axis we want to have: tests per 100k citizens and HIV infections per 100k citizens


# Only data from 2015 to 2017 will interest us, because those years are common 
# for both of our data sets, PKD data (2015-2022) and the second one from 1999 to 2017

# filter years accordingly
HIVdata_1517 <- HIVdata_9917 %>%
  _______________


# group by voivodeships and count observations
HIVdata_1517_woj <- HIVdata_1517 %>% 
  __________________ %>% 
  _________(positive = n())

nrow(HIVdata_1517_woj)

# there are 16 voivodeships, but 17 rows in a table, why?
# fix that
# hint: use head() to view the table






# fixed?
# now there should be 16 of them
# so we have two tables ready to merge

voi_1stmerge <- merge(wojCitizens, HIVdata_1517_woj, by= "Województwo")



# merged, now we want a column with positive cases per 100k citizens
# use positive and population_size to create it
voi_1stmerge <- voi_1stmerge %>% 
  mutate(posit100k= ______________________)

# let's just round those numbers now
voi_1stmerge$posit100k <- round(voi_1stmerge$posit100k, 1)



# Great!
# now we only need one more column, with number of tests per 100k citizens in those years

# Let's use a table from our previous visualization

head(positive_region)

# firstly let's filter Year, only observations from 2015 to 2017
# hint: use &

positive_region1517 <- positive_region %>% 
  __________________


# check if it worked, there should be only 2015, 2016, 2017
unique(positive_region1517$Year)



# now let's just group by (every observation is equal to one test, so count of them
# will give us number of tests)
# there should be two columns: Województwo, and tests

region1517_tests <- positive_region1517 %>% 
  group_by(__________) %>% 
  ____________________

nrow(region1517_tests)

# hmm, again we have 17 rows, fix that first





# Awesome!
# let's merge that with the previous table voi_1stmerge, merge by Województwo


testsPosit_1517 <- merge(____________, voi_1stmerge, by= __________)

# now we need only one thing, a column with tests per 100k citizens
# use tests and population_size

testsPosit_1517_100k <- ____________ %>% 
  mutate(tests100k= __________________)

# rounding
testsPosit_1517_100k$tests100k <- round(testsPosit_1517_100k$tests100k, 1)

head(testsPosit_1517_100k)


# let's save the file to use it in our dashboard
saveRDS(testsPosit_1517_100k, "testsPosit_1517_100k.RDS")






# number of new infections ------------------------------------------------

# we want to create a line plot with the number of infections across the years

HIVdata_9917 <- read.csv("HIV19992017PZH.csv")

# the data set
head(HIVdata_9917)



# group by year and count the observations
year_count <- HIVdata_9917 %>% 
  _____________ %>% 
  ________________


# let's save the file to use it in our dashboard
saveRDS(year_count, "year_count.RDS")




# That's it! Now play with the dashboard, make it look good


