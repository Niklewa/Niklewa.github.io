library(ggplot2)
library(ggthemes)
library(tidyverse)
library(dplyr)

# setting a working directory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

hc <- read.csv("hate_crime.csv", header = TRUE)

# column names
names(hc)
# number of rows
nrow(hc)

str(hc$STATE_ABBR)


hc$STATE_ABBR <- as.factor(hc$STATE_ABBR)


levels(hc$STATE_ABBR)


# here we are counting the number of observation for every state
# as observation equals recorded hate crimes, it gives us the number of
# hare crimes for every state

hcState <- hc %>% group_by(STATE_ABBR) %>% 
  summarise(OCCURRENCES = n()) 



arrange(hcState, desc(OCCURRENCES))

hcState <- arrange(hcState, desc(OCCURRENCES))



ggplot(hcState)+geom_col(
                  aes(x = STATE_ABBR, y = OCCURRENCES)
                            )


# ordering
ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, desc(OCCURRENCES)),
                  y = OCCURRENCES)
)


# improving readability 
ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() 


# adding a theme
ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() +
  theme_fivethirtyeight(base_size = 8)


# adding titles
ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() +
  theme_fivethirtyeight(base_size = 8)+
  labs(title = "Hate crimes in USA by state",
       subtitle = "1991-2017")


# changing title's position
ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() +
  theme_fivethirtyeight(base_size = 8)+
  labs(title = "Hate crimes in USA by state",
       subtitle = "1991-2017")+
  theme(plot.title.position = "plot")


# adding y label
ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() +
  theme_gdocs(base_size = 8)+
  labs(title = "Hate crimes in USA by state",
       subtitle = "1991-2017")+
  theme(plot.title.position = "plot")+
  ylab("total number of hate crimes")+
  xlab("")


# changing colors
ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES), fill = 'steelblue'
) + coord_flip() +
  theme_gdocs(base_size = 8)+
  labs(title = "Hate crimes in USA by state",
       subtitle = "1991-2017")+
  theme(plot.title.position = "plot")+
  ylab("total number of hate crimes")+
  xlab("")


# let's increase the size of values on axis
ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES), fill = 'steelblue'
) + coord_flip() +
  theme_gdocs(base_size = 8)+
  labs(title = "Hate crimes in USA by state",
       subtitle = "1991-2017")+
  theme(plot.title.position = "plot",
        axis.text = element_text(size = 11))+
  ylab("total number of hate crimes")+
  xlab("")


# changing numerical values on y axis (inverted!)

ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES), fill = 'steelblue'
) + coord_flip() +
  theme_gdocs(base_size = 8)+
  labs(title = "Hate crimes in USA by state",
       subtitle = "1991-2017")+
  theme(plot.title.position = "plot",
        axis.text = element_text(size = 11))+
  ylab("total number of hate crimes")+
  xlab("")+
  scale_y_continuous(breaks= seq(0, 30000, 5000))


#check out https://yutannihilation.github.io/allYourFigureAreBelongToUs/ggthemes/

#____________________________
#NOW YOUR TURN
#____________________________




# Ex 1 --------------------------------------------------------------------
# here we will prepare a line plot of hate crimes across the years
# and explore some themes that can be used on a visualization

#A. group by year and summarize by counts
hcYear <- hc %>% group_by(_____) %>% summarise(_____ = n())

#B. Check names and no of rows
names(_____)
nrow(_____)

#C. Rename the columns to "year" and "crimes"
names(hcYear) <- c(_____, _____)

#D. Prepare and inspect a basic plot of crimes vs years
hcYearPlot <- ggplot(hcYear, aes(x = _____, _____))+
  geom_line()

hcYearPlot

#E. add highcharts JS theme by adding theme_hc() and a meaningful title
#Highcharts JS theme 
hcYearPlot <- hcYearPlot + _____ + _____
hcYearPlot


#F. Now theme_gdocs()
#Google Docs Chart defaults with theme_gdocs
hcYearPlot <- hcYearPlot + _____
hcYearPlot


#G. Now  Few's "Practical rules for using color in charts", theme_few()
hcYearPlot <- hcYearPlot + _____
hcYearPlot


#H. Now fivethirtyeight.com
hcYearPlot <- hcYearPlot + _____
hcYearPlot


# Ex2 ---------------------------------------------------------------------



#A. Now group by DATA_YEAR, OFFENDER_RACE, summarize occurrences
# we will do something simmilar but by race of an offender



hcYearOffenderRace <- hc %>% _____     %>%
  summarise(_____, .groups = "keep")


#B factorize race and get rid of NAs
str(hcYearOffenderRace$OFFENDER_RACE)

hcYearOffenderRace$OFFENDER_RACE <- as.factor(_____)

levels(hcYearOffenderRace$OFFENDER_RACE)

#we will remove the NAs
sum(hcYearOffenderRace$OFFENDER_RACE == "")

sum(hcYearOffenderRace$OFFENDER_RACE != "")

hcYearOffenderRace <- hcYearOffenderRace %>%
            filter(OFFENDER_RACE != "")

sum(hcYearOffenderRace$OFFENDER_RACE == "")


#B. Prepare basic line plot of occurrences vs year, colored by offender race


names(hcYearOffenderRace)

ggplot(hcYearOffenderRace) + geom_line(
          aes (_____  , _____, color = _______ )
          )


#C. Now make it nice using tools we introduced in the previous example





#_____________________________________






# Ex3 ---------------------------------------------------------------------
## Now we're interested in the relation between victim and offender counts


#A. Use hc to prep a jitterplot of victim counts vs offender counts


vcPLot <- ggplot(hc) + geom_jitter(aes(_____  , _____))
vcPlot


#B. use xlim(0,25) and ylim(0,25) to inspect a frament of the data

vcPlot  +  _____ + _____


#C. Make this prettier using what we have learned before, fixing point size 
#and alpha






# Ex4 ---------------------------------------------------------------------

names(hc)



#A. Do offender races have impact on offender group sizes? Draw a boxplot, 
#limit y t0 0,15

ggplot(_____) + geom_boxplot(aes( _____, 
                                  _____))+
                          coord_flip()+ _____


#B. How about offender races and victim group sizes? This time do a 
#scatterplot with jitter, same limit on  y


ggplot(hc) + _____(aes( _____, 
                        _____))+
  coord_flip()+_____


#C Make this look pretty 





# Ex5 ---------------------------------------------------------------------

# Do you want to do something extra?
# Prepare a plot of variables of your choice

# you can explore the dataset using:

names(hc)

head(hc)











